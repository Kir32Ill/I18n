export { ArticleI18nKz } from "./ArticleI18nKz";
