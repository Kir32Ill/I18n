import { type FC } from "react";
import { FormattedMessage } from "react-intl";

import { Layout } from "@/components";
import { useLocale } from "@/providers/useLocale";

import styles from "./styles.module.css";

export const ArticleCss: FC = () => {
  const { locale } = useLocale();
     const renderHtml = (message: string) => (
    <div dangerouslySetInnerHTML={{ __html: message }} />
  );
  const code = (chunks: React.ReactNode[]) => <code>{chunks}</code>;
  return (
    <Layout >
      <main 
        className={styles.article} 
        dir={locale.startsWith('ar') ? 'rtl' : 'ltr'}
        lang={locale.split('-')[0]}
      >
        <h1>
          <FormattedMessage 
            id="articleCss.title"
            defaultMessage="Using Logical CSS Properties for Internationalized Interfaces"
          />
        </h1>

        <p>
          <FormattedMessage 
            id="articleCss.intro"
            defaultMessage="In recent years, more attention has been paid to creating truly global web products. This is especially relevant for projects whose audience is distributed worldwide. When developing interfaces in languages such as Arabic, where text and layout direction go from right to left (RTL), it's important that the visual behavior of components remains intuitive. One of the key tools for this is logical CSS properties."
          />
        </p>

        <p>
          <FormattedMessage 
            id="articleCss.diff"
            defaultMessage="Unlike physical properties (e.g., <code>margin-left</code>, <code>padding-right</code>, <code>border-top</code>), logical properties (<code>margin-inline-start</code>, <code>padding-block-end</code>, <code>border-inline</code>) describe behavior relative to the writing direction rather than a fixed screen direction. This is especially important in projects where content can be in English, Arabic, Chinese, Russian, and other languages with different directions."
            values={{ code }}
          />
        </p>

        <section className={styles.section}>
          <h2>
            <FormattedMessage 
              id="articleCss.whyImportant.title"
              defaultMessage="Why This Matters for i18n Frontend"
            />
          </h2>

          <p>
            <FormattedMessage 
              id="articleCss.whyImportant.text"
              defaultMessage="Using logical properties makes the code more adaptive and reduces the need for conditional styles or CSS duplication. It also simplifies maintenance, especially in multilingual products where switching between LTR and RTL should be as seamless as possible."
            />
          </p>
           
            <div className={styles.listContainer}>
                    <p>
                    <FormattedMessage 
                    id="articleCss.whyImportant.list"
                    defaultMessage="Here are some benefits:"
                    />
                    </p>
                <div className={styles.no}>
                    <FormattedMessage
                    id="articleCss.whyImportant.listItems"
                    // eslint-disable-next-line formatjs/enforce-placeholders
                    defaultMessage="<ul><li>Universality...</li></ul>"
                    >
                    {(message) => (
                        <div className={styles.listWrapper}>
                        {renderHtml(message as unknown as string)}
                        </div>
                    )}
                    </FormattedMessage>
                </div>
            </div>
          
        </section>

        <section className={styles.section}>
          <h2>
            <FormattedMessage 
              id="articleCss.conclusion.title"
              defaultMessage="Conclusion"
            />
          </h2>

          <p>
            <FormattedMessage 
              id="articleCss.conclusion.text"
              defaultMessage="Using logical CSS properties is a simple and effective way to make interfaces truly adaptive and globally oriented. This approach allows for consideration of linguistic and cultural differences without complicating the code or duplicating styles."
            />
          </p>
        </section>
      </main>
    </Layout>
  );
};